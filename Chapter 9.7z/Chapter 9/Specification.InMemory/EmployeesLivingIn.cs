﻿using Domain;

namespace Specification.InMemory
{
    public class EmployeesLivingIn : Specification<Employee>
    {
        private readonly string city;

        public EmployeesLivingIn(string city)
        {
            this.city = city;
        }

        public override bool IsSatisfiedBy(Employee entity)
        {
            return entity.ResidentialAddress.City == city;
        }
    }
}