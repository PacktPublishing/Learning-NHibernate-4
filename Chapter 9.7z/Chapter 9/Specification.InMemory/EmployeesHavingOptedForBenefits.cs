﻿using Domain;

namespace Specification.InMemory
{
    public class EmployeesHavingOptedForBenefits : Specification<Employee>
    {
        public override bool IsSatisfiedBy(Employee entity)
        {
            return entity.Benefits.Count > 0;
        }
    }
}