﻿using System.Collections.Generic;
using System.Linq;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Query
{
    public class EmployeesLivingIn : IQuery<Employee>
    {
        private readonly string city;

        public EmployeesLivingIn(string city)
        {
            this.city = city;
        }

        public IEnumerable<Employee> Run(IQueryable<Employee> employees)
        {
            return (from e in employees
                where e.ResidentialAddress.City == city
                select e).ToList();
        }
    }
}