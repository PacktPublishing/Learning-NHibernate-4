﻿using System;
using System.Linq.Expressions;
using Domain;

namespace DomainService.Capabilities
{
    public interface ISpecification<T> where T : EntityBase<T>
    {
        Expression<Func<T, bool>> IsSatisfied();
    }
}