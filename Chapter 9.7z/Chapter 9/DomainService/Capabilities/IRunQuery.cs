﻿using System.Collections.Generic;
using Domain;

namespace DomainService.Capabilities
{
    public interface IRunQuery
    {
        IEnumerable<T> Run<T>(IQuery<T> query) where T : EntityBase<T>;
        IEnumerable<T1> Run<T1, T2>(IQuery<T1, T2> query) 
            where T1 : EntityBase<T1>
            where T2 : EntityBase<T2>;
        IEnumerable<T1> Run<T1, T2>(IBenefitQuery<T1, T2> query)
            where T1 : EntityBase<T1>
            where T2 : Benefit;
    }
}