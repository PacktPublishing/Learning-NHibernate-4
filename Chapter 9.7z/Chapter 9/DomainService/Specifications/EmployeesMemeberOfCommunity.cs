﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Specifications
{
    public class EmployeesMemberOfCommunity : ISpecification<Employee>
    {
        private readonly string communityName;

        public EmployeesMemberOfCommunity(string communityName)
        {
            this.communityName = communityName;
        }

        public Expression<Func<Employee, bool>> IsSatisfied()
        {
            return e => e.Communities.Any(c => c.Name == communityName);
        }
    }
}