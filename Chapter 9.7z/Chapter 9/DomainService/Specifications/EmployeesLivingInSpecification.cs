﻿using System;
using System.Linq.Expressions;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Specifications
{
    public class EmployeeLivingIn : Specification<Employee>
    {
        private readonly string city;

        public EmployeeLivingIn(string city)
        {
            this.city = city;
        }

        public override Expression<Func<Employee, bool>> IsSatisfied()
        {
            return e => e.ResidentialAddress.City == city;
        }
    }
}