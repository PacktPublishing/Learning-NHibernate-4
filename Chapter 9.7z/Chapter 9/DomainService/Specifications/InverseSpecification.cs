using System;
using System.Linq.Expressions;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Specifications
{
    public class InverseSpecification<T> : Specification<T> where T : EntityBase<T>

    {
        private readonly ISpecification<T> specification1;

        public InverseSpecification(ISpecification<T> specification1)
        {
            this.specification1 = specification1;
        }

        public override Expression<Func<T, bool>> IsSatisfied()
        {
            var parameterName = Expression.Parameter(typeof(T), "arg1");
            return Expression.Lambda<Func<T, bool>>(
                Expression.Not(
                    Expression.Invoke(specification1.IsSatisfied(), parameterName)
                    ),
                parameterName
                );
        }
    }
}