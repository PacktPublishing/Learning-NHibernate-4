﻿using System;
using System.Linq.Expressions;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Specifications
{
    public class EmployeeHavingIdSpecification : ISpecification<Employee>
    {
        private readonly int identifier;

        public EmployeeHavingIdSpecification(int identifier)
        {
            this.identifier = identifier;
        }

        public Expression<Func<Employee, bool>> IsSatisfied()
        {
            return e => e.Id == identifier;
        }
    }
}