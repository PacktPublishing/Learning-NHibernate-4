using System.Collections.Generic;
using System.Linq;
using Domain;
using DomainService.Specifications;
using NHibernate.Linq;
using NUnit.Framework;
using Tests.Unit.QueryTests;

namespace Tests.Unit.Specifications
{
    [TestFixture]
    public class EmployeesHavingTakenSeasonTicketLoanTests : QueryTest
    {
        [Test]
        public void ExecuteSpecification()
        {
            IList<Employee> employees = null;
            using (var transaction = Database.Session.BeginTransaction())
            {
                var specification = new EmployeeHavingTakenSeasonTicketLoanSepcification();
                employees = Database.Session.Query<Employee>().Where(specification.IsSatisfied())
                                            .ToList();

                transaction.Commit();

            }

            Assert.That(employees.Count, Is.EqualTo(2));
        }
    }
}