﻿using System;

namespace Domain
{
    public interface IAmAudited
    {
        DateTime CreatedAt { get; set; }
    }
}