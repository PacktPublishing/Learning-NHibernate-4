﻿using System;
using System.Linq;
using Domain;
using NHibernate.Linq;
using NUnit.Framework;

namespace Tests.Unit
{
    [TestFixture]
    public class CachingTests : TestUsingInMemoryDatabase
    {
        [Test]
        public void SessionLevelCacheIsUsedOnlyForGet()
        {
            object id = 0;
            using (var tx1 = Session.BeginTransaction())
            {
                id = Session.Save(new Employee
                {
                    Firstname = "John",
                    Lastname = "Smith"
                });

                tx1.Commit();
            }

            using (var tx2 = Session.BeginTransaction())
            {
                var employee = Session.Get<Employee>(id);
                Assert.That(employee.CreatedAt, Is.Not.EqualTo(DateTime.MinValue));
                tx2.Commit();
            }

            using (var tx2 = Session.BeginTransaction())
            {
                var employee = Session.Query<Employee>().First(e => e.Firstname == "John");
                Assert.That(employee.CreatedAt, Is.Not.EqualTo(DateTime.MinValue));
                tx2.Commit();
            }
        }

    }
}