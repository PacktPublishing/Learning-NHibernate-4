﻿using System.Collections.Generic;
using System.Linq;
using Domain;
using DomainService.Query;
using NUnit.Framework;
using Persistence;
using Tests.Unit.QueryTests;

namespace Tests.Unit.QueryObjectTests
{
    [TestFixture]
    public class EmployeesMemberOfCommunityTests : QueryTest
    {
        [Test]
        public void RunQuery()
        {
            IEnumerable<Employee> employees = null;
            using (var transaction = Database.Session.BeginTransaction())
            {
                var query = new EmployeeHavingTakenSeasonTicketLoanQuery();
                var queryRunner = new QueryRunner(Database.Session);
                employees = queryRunner.Run(query);

                transaction.Commit();

            }

            Assert.That(employees.Count(), Is.EqualTo(2));
        }
    }
}