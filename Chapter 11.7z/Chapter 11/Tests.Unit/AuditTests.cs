﻿using System;
using Domain;
using NUnit.Framework;

namespace Tests.Unit
{
    [TestFixture]
    public class AuditTests : TestUsingInMemoryDatabase
    {
        [Test]
        public void CreatedAtIsSetWhenSavingNewInstance()
        {
            object id = 0;
            using (var tx = Session.BeginTransaction())
            {
                id = Session.Save(new Employee
                {
                    Firstname = "John",
                    Lastname = "Smith"
                });

                tx.Commit();
            }

            Session.Clear();

            using (var tx = Session.BeginTransaction())
            {
                var employee = Session.Get<Employee>(id);
                Assert.That(employee.CreatedAt, Is.Not.EqualTo(DateTime.MinValue));
                tx.Commit();
            }
        }
    }
}