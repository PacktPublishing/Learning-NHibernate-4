﻿using System;
using Domain;
using NHibernate;
using NUnit.Framework;

namespace Tests.Unit
{
    [TestFixture]
    public class ConcurrencyControlTests
    {
        protected SqlServerDatabase Database;
        public ConcurrencyControlTests()
        {
            Database = new SqlServerDatabase();
            Database.Initialize();
        }

        [Test]
        public void PessimisticConcurrencyControlTest()
        {
            object id = 0;
            using (var tx = Database.Session.BeginTransaction())
            {
                id = Database.Session.Save(new Employee
                {
                    Firstname = "John",
                    Lastname = "Smith",
                    DateOfBirth = new DateTime(1972, 3, 5),
                    DateOfJoining = new DateTime(2001, 5, 28),
                });

                tx.Commit();
            }

            Database.Session.Clear();

            using (var tx = Database.Session.BeginTransaction())
            {
                var emp = Database.Session.Get<Employee>(id);
                Database.Session.Lock(emp, LockMode.Upgrade);
                emp.Firstname = "Hillary";
                emp.Lastname = "Gamble";
                tx.Commit();
            }

            Database.Session.Clear();

            using (var tx = Database.Session.BeginTransaction())
            {
                var employee = Database.Session.Get<Employee>(id);
                Assert.That(employee.Firstname, Is.EqualTo("Hillary"));
                tx.Commit();
            }
        }

        [Test]
        public void OptimisticConcurrencyControlUsingTimeStampTest()
        {
            object id = 0;
            using (var tx = Database.Session.BeginTransaction())
            {
                id = Database.Session.Save(new Employee
                {
                    Firstname = "John",
                    Lastname = "Smith",
                    DateOfBirth = new DateTime(1972, 3, 5),
                    DateOfJoining = new DateTime(2001, 5, 28),
                });

                tx.Commit();
            }

            Database.Session.Clear();

            using (var tx = Database.Session.BeginTransaction())
            {
                var emp = Database.Session.Get<Employee>(id);
                emp.Firstname = "Hillary";
                emp.Lastname = "Gamble";
                tx.Commit();
            }

            Database.Session.Clear();

            using (var tx = Database.Session.BeginTransaction())
            {
                var employee = Database.Session.Get<Employee>(id);
                Assert.That(employee.Firstname, Is.EqualTo("Hillary"));
                tx.Commit();
            }
        }

    }
}