﻿using System.Linq;
using Domain;
using DomainService.Specifications;
using NHibernate.Linq;
using NUnit.Framework;
using Persistence;
using Tests.Unit.QueryTests;

namespace Tests.Unit
{
    [TestFixture]
    public class SpecificationTests : QueryTest
    {
        [Test]
        public void ReturnEmployeesLivingInLondon_UsingSession()
        {
            using (var transaction = Database.Session.BeginTransaction())
            {
                var specification = new EmployeeLivingIn("London");
                var employees = Database.Session.Query<Employee>().Where(specification.IsSatisfied());

                Assert.That(employees.Count(), Is.EqualTo(3));
                transaction.Commit();
            }
        }

        [Test]
        public void ReturnEmployeesLivingInLondon_UsingRepository()
        {
            using (var transaction = Database.Session.BeginTransaction())
            {
                var specification = new EmployeeLivingIn("London");
                var repository = new Repository<Employee>(Database.Session);

                var employees = repository.Apply(specification);

                Assert.That(employees.Count(), Is.EqualTo(3));
                transaction.Commit();
            }
        }

        [Test]
        public void ReturnEmployeesLivingInLondonAndHavingTakenSeasonTicketLoan()
        {
            using (var transaction = Database.Session.BeginTransaction())
            {
                var livingInLondon = new EmployeeLivingIn("London");
                var haveTakenSeasonTicketLoan = new EmployeeHavingTakenSeasonTicketLoanSepcification();

                var employees = Database.Session.Query<Employee>().Where(livingInLondon.And(haveTakenSeasonTicketLoan).IsSatisfied());

                Assert.That(employees.Count(), Is.EqualTo(2));
                transaction.Commit();
            }
        }
    }
}