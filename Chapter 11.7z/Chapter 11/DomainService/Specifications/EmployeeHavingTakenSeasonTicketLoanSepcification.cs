﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Domain;

namespace DomainService.Specifications
{
public class EmployeeHavingTakenSeasonTicketLoanSepcification :Specification<Employee>
{
    public override Expression<Func<Employee, bool>> IsSatisfied()
    {
        return e =>  e.Benefits.Any(b => b is SeasonTicketLoan);
    }
}
}