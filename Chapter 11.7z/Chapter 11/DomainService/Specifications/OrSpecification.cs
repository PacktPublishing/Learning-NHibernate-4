﻿using System;
using System.Linq.Expressions;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Specifications
{
    public class OrSpecification<T> : Specification<T> where T : EntityBase<T>

    {
        private readonly ISpecification<T> specification1;
        private readonly ISpecification<T> specification2;

        public OrSpecification(ISpecification<T> specification1, ISpecification<T> specification2)
        {
            this.specification1 = specification1;
            this.specification2 = specification2;
        }

        public override Expression<Func<T, bool>> IsSatisfied()
        {
            var parameterName = Expression.Parameter(typeof(T), "arg1");
            return Expression.Lambda<Func<T, bool>>(
                Expression.OrElse(
                    Expression.Invoke(specification1.IsSatisfied(), parameterName),
                    Expression.Invoke(specification2.IsSatisfied(), parameterName)
                    ),
                parameterName
                );
        }
    }
}