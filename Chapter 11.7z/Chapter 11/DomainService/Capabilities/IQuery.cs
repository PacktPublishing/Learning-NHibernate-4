﻿using System.Collections.Generic;
using System.Linq;
using Domain;

namespace DomainService.Capabilities
{
public interface IQuery<T> where T : EntityBase<T>
{
    IEnumerable<T> Run(IQueryable<T> queryable);
}
    public interface IQuery<T1, in T2> 
        where T1 : EntityBase<T1>
        where T2 : EntityBase<T2>
    {
        IEnumerable<T1> Run(IQueryable<T1> queryable1, IQueryable<T2> queryable2);
    }

    public interface IBenefitQuery<T1, in T2>
        where T1 : EntityBase<T1>
        where T2 : Benefit
    {
        IEnumerable<T1> Run(IQueryable<T1> queryable1, IQueryable<T2> queryable2);
    }
}