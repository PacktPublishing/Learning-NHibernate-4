﻿using System.Collections.Generic;
using System.Linq;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Query
{
    public class EmployeeHavingTakenSeasonTicketLoanQuery : IBenefitQuery<Employee, SeasonTicketLoan>
    {
        public IEnumerable<Employee> Run(IQueryable<Employee> employees, IQueryable<SeasonTicketLoan> seasonTicketLoans)
        {
            return (from e in employees
                    join s in seasonTicketLoans on e equals  s.Employee
                    select e).ToList();
        }
    }
}