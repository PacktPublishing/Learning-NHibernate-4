﻿using System.Collections.Generic;
using System.Linq;
using Domain;
using DomainService.Capabilities;

namespace DomainService.Query
{
    public class EmployeeByIdQuery : IQuery<Employee>
    {
        private readonly int identifier;

        public EmployeeByIdQuery(int identifier)
        {
            this.identifier = identifier;
        }

        public IEnumerable<Employee> Run(IQueryable<Employee> employees)
        {
            return (from e in employees
                where e.Id == identifier
                select e).ToList();
        }
    }
}