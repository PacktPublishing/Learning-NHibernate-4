﻿using System.Collections.Generic;
using Domain;
using DomainService.Capabilities;
using NHibernate;
using NHibernate.Linq;

namespace Persistence
{
    public class QueryRunner : IRunQuery
    {
        private readonly ISession session;

        public QueryRunner(ISession session)
        {
            this.session = session;
        }

        public IEnumerable<T> Run<T>(IQuery<T> query) where T : EntityBase<T>
        {
            return query.Run(session.Query<T>());
        }

        public IEnumerable<T1> Run<T1, T2>(IQuery<T1, T2> query) where T1 : EntityBase<T1> where T2 : EntityBase<T2>
        {
            return query.Run(session.Query<T1>(), session.Query<T2>());
        }

        public IEnumerable<T1> Run<T1, T2>(IBenefitQuery<T1, T2> query) where T1 : EntityBase<T1> where T2 : Benefit
        {
            return query.Run(session.Query<T1>(), session.Query<T2>());
        }
    }
}