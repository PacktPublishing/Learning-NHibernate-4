﻿using System;
using Domain;
using NHibernate.Event;

namespace Persistence
{
    public class AuditableEventListener : IPreInsertEventListener
    {
        public bool OnPreInsert(PreInsertEvent @event)
        {
            var auditInfo = @event.Entity as IAmAudited;

            if (auditInfo == null) return false;

            var createdAtPropertyIndex = Array.IndexOf(@event.Persister.PropertyNames, "CreatedAt");

            if (createdAtPropertyIndex == -1) return false;

            var createdAt = DateTime.Now;
            @event.State[createdAtPropertyIndex] = createdAt;
            auditInfo.CreatedAt = createdAt;

            return false;

        }
    }
}