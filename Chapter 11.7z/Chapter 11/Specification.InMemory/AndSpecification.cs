namespace Specification.InMemory
{
    public class AndSpecification<T> : Specification<T>
    {
        private readonly Specification<T> specification1;
        private readonly ISpecification<T> specification2;

        public AndSpecification(Specification<T> specification1, ISpecification<T> specification2)
        {
            this.specification1 = specification1;
            this.specification2 = specification2;
        }

        public override bool IsSatisfiedBy(T entity)
        {
            return specification1.IsSatisfiedBy(entity) && specification2.IsSatisfiedBy(entity);
        }
    }
}