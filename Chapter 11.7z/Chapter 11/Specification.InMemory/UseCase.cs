﻿using System.Collections.Generic;
using Domain;

namespace Specification.InMemory
{
    public class UseCase
    {
        public void Use1()
        {
            List<Employee> employees = null; //= Load the list of employees from somewhere
            List<Employee> employeesLivingInLondon = new List<Employee>();
            var emplyeesLivingInLondonSpecification = new EmployeesLivingIn("London");

            foreach (var employee in employees)
            {
                if (emplyeesLivingInLondonSpecification.IsSatisfiedBy(employee))
                {
                    employeesLivingInLondon.Add(employee);
                }
            }
        }

        public void Use2()
        {
List<Employee> employees = null; //= Load the list of employees from somewhere
List<Employee> employeesLivingInLondon = new List<Employee>();
var specification = new EmployeesLivingIn("London").And(new EmployeesHavingOptedForBenefits());

foreach (var employee in employees)
{
    if (specification.IsSatisfiedBy(employee))
    {
        employeesLivingInLondon.Add(employee);
    }
}
        }
    }
}